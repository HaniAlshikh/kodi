from .m3u_parser import M3uParser

__version__ = '0.2.0'
